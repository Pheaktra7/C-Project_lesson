﻿namespace calculate_latter_grade
{
    partial class frmCalculateLatterGrade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNumeric = new System.Windows.Forms.Label();
            this.txtLatterGrade = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtnumber = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtNumeric
            // 
            this.txtNumeric.AutoSize = true;
            this.txtNumeric.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumeric.Location = new System.Drawing.Point(80, 45);
            this.txtNumeric.Name = "txtNumeric";
            this.txtNumeric.Size = new System.Drawing.Size(161, 31);
            this.txtNumeric.TabIndex = 0;
            this.txtNumeric.Text = "Numeric Grade";
            this.txtNumeric.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.txtNumeric.UseCompatibleTextRendering = true;
            // 
            // txtLatterGrade
            // 
            this.txtLatterGrade.AutoSize = true;
            this.txtLatterGrade.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLatterGrade.Location = new System.Drawing.Point(80, 119);
            this.txtLatterGrade.Name = "txtLatterGrade";
            this.txtLatterGrade.Size = new System.Drawing.Size(135, 31);
            this.txtLatterGrade.TabIndex = 1;
            this.txtLatterGrade.Text = "Latter Grade";
            this.txtLatterGrade.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.txtLatterGrade.UseCompatibleTextRendering = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(338, 126);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(240, 30);
            this.textBox2.TabIndex = 0;
            this.textBox2.TabStop = false;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(166, 233);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(110, 60);
            this.btnCalculate.TabIndex = 2;
            this.btnCalculate.Text = "&Calculate Latter Grade";
            this.btnCalculate.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(407, 233);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(110, 60);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // txtnumber
            // 
            this.txtnumber.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtnumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtnumber.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtnumber.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtnumber.Location = new System.Drawing.Point(338, 46);
            this.txtnumber.Multiline = true;
            this.txtnumber.Name = "txtnumber";
            this.txtnumber.Size = new System.Drawing.Size(240, 30);
            this.txtnumber.TabIndex = 1;
            // 
            // frmCalculateLatterGrade
            // 
            this.AcceptButton = this.btnCalculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(651, 453);
            this.Controls.Add(this.txtnumber);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.txtLatterGrade);
            this.Controls.Add(this.txtNumeric);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name = "frmCalculateLatterGrade";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculate Latter Grade";
            this.TransparencyKey = System.Drawing.Color.White;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtNumeric;
        private System.Windows.Forms.Label txtLatterGrade;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtnumber;
    }
}

