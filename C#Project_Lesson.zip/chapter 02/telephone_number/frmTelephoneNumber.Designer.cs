﻿namespace telephone_number
{
    partial class frmTelephoneNumber
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtAlphunamericNumber = new System.Windows.Forms.TextBox();
            this.txtNumeric = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnConvertNumeric = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Alphunameric Number";
            // 
            // txtAlphunamericNumber
            // 
            this.txtAlphunamericNumber.Location = new System.Drawing.Point(207, 56);
            this.txtAlphunamericNumber.Multiline = true;
            this.txtAlphunamericNumber.Name = "txtAlphunamericNumber";
            this.txtAlphunamericNumber.Size = new System.Drawing.Size(140, 25);
            this.txtAlphunamericNumber.TabIndex = 1;
            // 
            // txtNumeric
            // 
            this.txtNumeric.Location = new System.Drawing.Point(207, 122);
            this.txtNumeric.Multiline = true;
            this.txtNumeric.Name = "txtNumeric";
            this.txtNumeric.ReadOnly = true;
            this.txtNumeric.Size = new System.Drawing.Size(140, 25);
            this.txtNumeric.TabIndex = 0;
            this.txtNumeric.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Numeric Only";
            // 
            // btnConvertNumeric
            // 
            this.btnConvertNumeric.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnConvertNumeric.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnConvertNumeric.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnConvertNumeric.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConvertNumeric.Location = new System.Drawing.Point(72, 219);
            this.btnConvertNumeric.Name = "btnConvertNumeric";
            this.btnConvertNumeric.Size = new System.Drawing.Size(75, 50);
            this.btnConvertNumeric.TabIndex = 2;
            this.btnConvertNumeric.Text = "&Convert to Numeric Only";
            this.btnConvertNumeric.UseVisualStyleBackColor = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(221, 219);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 50);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = false;
            // 
            // frmTelephoneNumber
            // 
            this.AcceptButton = this.btnConvertNumeric;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(374, 351);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnConvertNumeric);
            this.Controls.Add(this.txtNumeric);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtAlphunamericNumber);
            this.Controls.Add(this.label1);
            this.Name = "frmTelephoneNumber";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Telephone Numbers";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAlphunamericNumber;
        private System.Windows.Forms.TextBox txtNumeric;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnConvertNumeric;
        private System.Windows.Forms.Button btnExit;
    }
}

